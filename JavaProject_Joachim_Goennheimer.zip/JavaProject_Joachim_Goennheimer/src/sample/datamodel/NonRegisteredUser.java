package sample.datamodel;


/**
 * Class to improve understandability of object model. No new attributes.
 */
public class NonRegisteredUser extends User {

}
